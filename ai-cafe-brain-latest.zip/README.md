# AI Café Brain (latest)
Controller + Display + JSON storage + pricing helper. No database required.

## Features
- Quick-add new menu items from natural text, with auto COGS estimation and price suggestion (min 3× COGS by default, rounded to .90).
- Ingredients parser supports simple units like `50g ham@$0.02/g` or defaults to heuristics.
- Prep markers ("fake skis") for timing kitchen tasks, synced to display via websockets.
- Simple orders API scaffold.
- JSON storage in `data/` so you can copy between machines without drama.

## Install
```bash
# 1) extract zip
cd ai-cafe-brain-latest

# 2) set env (optional)
cp .env.example .env   # edit if you want different port/markup rules

# 3) install
npm install

# 4) run
npm start
# opens on http://localhost:5050

# Optional: use pm2
# pm2 start server.js --name cafe --env production
```

## Pages
- Controller: `http://localhost:5050/` for quick adds, products, and markers.
- Display: `http://localhost:5050/display.html` for kitchen view.

## API Cheatsheet
- `GET /api/health`
- `GET /api/products`
- `POST /api/products` body:
```json
{
  "quickAddText": "New toastie called Truffle Hog; add to fav",
  "ingredientsText": "50g ham, 50g salami, 20g truffle mayo, 20g rocket"
}
```
- `POST /api/price/suggest` body: `{ "cogs": 3.5 }`
- `GET /api/markers`
- `POST /api/markers` body: `{ "label":"Focaccia batch", "minutes":12 }`
- `DELETE /api/markers/:id`

## Data
- `data/products.json`
- `data/orders.json`
- `data/markers.json`

Backup or share those three files to move state.

## Notes
- This is local-first. No Square integration here. Hook it later via their API if you must.
- Pricing knobs in `.env`: `MIN_MARKUP`, `PRICE_ROUNDING`, `PSYCH_ENDING`.
