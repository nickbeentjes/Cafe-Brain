
require('dotenv').config();
const express = require('express');
const http = require('http');
const path = require('path');
const fs = require('fs');
const morgan = require('morgan');
const { Server } = require('socket.io');
const { v4: uuidv4 } = require('uuid');
const createError = require('http-errors');
const bodyParser = require('body-parser');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });

// Config
const PORT = process.env.PORT || 5050;
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const MIN_MARKUP = parseFloat(process.env.MIN_MARKUP || "3.0");
const PRICE_ROUNDING = parseFloat(process.env.PRICE_ROUNDING || "0.5"); // round to nearest 50c by default
const PSYCH_ENDING = parseFloat(process.env.PSYCH_ENDING || "0.90");     // force .90 ending in AU vibe

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

const FILES = {
  products: path.join(DATA_DIR, 'products.json'),
  orders: path.join(DATA_DIR, 'orders.json'),
  markers: path.join(DATA_DIR, 'markers.json')
};

function readJSON(file, fallback) {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf-8'));
  } catch (e) {
    return fallback;
  }
}

function writeJSON(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

// Pricing helper
function suggestPrice(cogs, opts = {}) {
  const minMarkup = opts.minMarkup ?? MIN_MARKUP;
  const target = cogs * minMarkup;
  const rounded = Math.round(target / PRICE_ROUNDING) * PRICE_ROUNDING;
  // Apply psychological ending if provided and reasonable
  let price = rounded;
  if (!Number.isNaN(PSYCH_ENDING)) {
    const dollars = Math.floor(price);
    price = dollars + PSYCH_ENDING;
    if (price < target) {
      price += PRICE_ROUNDING; // bump to cover minimum
    }
  }
  // to 2dp
  return Math.round(price * 100) / 100;
}

// Basic COGS parser: "50g ham, 50g salami, 20g mayo@$0.02/g"
// If no unit costs are provided, fall back to an estimated $0.02/gram for meats, $0.01/gram for greens, $0.03/gram for premium condiments.
function estimateCogsFromText(text) {
  const parts = text.split(/[,;+]/).map(p => p.trim()).filter(Boolean);
  let cogs = 0;
  for (const p of parts) {
    const m = p.match(/(\d+(?:\.\d+)?)\s*(g|kg|ml|l)?\s*([a-zA-Z ]+)(?:@\$?\s*(\d+(?:\.\d+)?)(?:\s*\/\s*(g|kg|ml|l))?)?/i);
    if (!m) continue;
    let qty = parseFloat(m[1]);
    let unit = (m[2] || '').toLowerCase();
    const name = m[3].trim().toLowerCase();
    let unitCost = m[4] ? parseFloat(m[4]) : null;
    let unitCostUnit = (m[5] || '').toLowerCase();

    // normalise units to grams or ml
    let grams = 0;
    if (unit === 'kg') grams = qty * 1000;
    else if (unit === 'g' || unit === '') grams = qty;
    else if (unit === 'l') grams = qty * 1000;
    else if (unit === 'ml') grams = qty;

    if (unitCost != null) {
      // convert unit cost to per-gram if needed
      if (unitCostUnit === 'kg' || unitCostUnit === 'l') unitCost = unitCost / 1000;
      // unitCost now cost per gram/ml
      cogs += grams * unitCost;
    } else {
      // heuristic defaults
      let defaultPerGram = 0.02; // meats default
      if (/(rocket|lettuce|spinach|greens)/.test(name)) defaultPerGram = 0.01;
      if (/(truffle|pesto|aioli|mayo|sauce|cheese)/.test(name)) defaultPerGram = 0.03;
      cogs += grams * defaultPerGram;
    }
  }
  return Math.round(cogs * 100) / 100;
}

// Quick add parser: "new focaccia called megeat for $16 fav"
function parseQuickAdd(text) {
  const nameMatch = text.match(/called\s+([a-z0-9 \-\_]+)/i);
  const priceMatch = text.match(/\$\s?(\d+(?:\.\d+)?)/i);
  const fav = /fav(ou?rite)?|add to fav/i.test(text);
  const category = /coffee|drink|food|sandwich|toastie/i.test(text) ? (text.match(/coffee|drink|food|sandwich|toastie/i)[0].toLowerCase()) : 'food';
  const name = nameMatch ? nameMatch[1].trim() : (text.match(/new\s+([a-z0-9 \-\_]+)/i)?.[1]?.trim() || 'New Item');
  const price = priceMatch ? parseFloat(priceMatch[1]) : null;
  return { name, price, favourite: fav, category };
}

app.use(morgan('tiny'));
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

// API routes
app.get('/api/health', (req, res)=> res.json({ok:true, now: new Date().toISOString()}));

app.get('/api/products', (req, res)=> {
  const db = readJSON(FILES.products, { products: [] });
  res.json(db.products);
});

app.post('/api/products', (req, res)=> {
  const db = readJSON(FILES.products, { products: [] });
  const { name, category = 'food', favourite = false, sku, cogs, price, quickAddText, ingredientsText } = req.body;

  let finalName = name;
  let finalFav = favourite;
  let finalCategory = category;
  let finalCOGS = typeof cogs === 'number' ? cogs : null;
  let finalPrice = typeof price === 'number' ? price : null;

  if (quickAddText) {
    const q = parseQuickAdd(quickAddText);
    finalName = finalName || q.name;
    finalFav = finalFav || q.favourite;
    finalCategory = finalCategory || q.category;
    if (!finalPrice && q.price) finalPrice = q.price;
  }

  if (!finalCOGS && ingredientsText) {
    finalCOGS = estimateCogsFromText(ingredientsText);
  }

  if (!finalPrice && finalCOGS != null) {
    finalPrice = suggestPrice(finalCOGS);
  }

  if (!finalName) return res.status(400).json({error:"Missing name"});

  const item = {
    id: uuidv4(),
    name: finalName,
    category: finalCategory,
    favourite: !!finalFav,
    sku: sku || null,
    cogs: typeof finalCOGS === 'number' ? finalCOGS : null,
    price: typeof finalPrice === 'number' ? finalPrice : null,
    createdAt: new Date().toISOString()
  };
  db.products.push(item);
  writeJSON(FILES.products, db);
  io.emit('products:update', item);
  res.json({saved:true, item});
});

app.post('/api/price/suggest', (req, res)=> {
  const { cogs, minMarkup } = req.body;
  if (typeof cogs !== 'number') return res.status(400).json({ error: "cogs required" });
  const price = suggestPrice(cogs, { minMarkup });
  res.json({ cogs, price, minMarkup: minMarkup ?? MIN_MARKUP });
});

// Prep markers ("fake skis") to time prep tasks
app.get('/api/markers', (req, res)=> {
  const db = readJSON(FILES.markers, { markers: [] });
  res.json(db.markers);
});

app.post('/api/markers', (req, res)=> {
  const db = readJSON(FILES.markers, { markers: [] });
  const { label, minutes = 5 } = req.body;
  const marker = { id: uuidv4(), label: label || 'Prep', minutes, start: Date.now() };
  db.markers.push(marker);
  writeJSON(FILES.markers, db);
  io.emit('markers:update', marker);
  res.json({ saved: true, marker });
});

app.delete('/api/markers/:id', (req, res)=> {
  const db = readJSON(FILES.markers, { markers: [] });
  const before = db.markers.length;
  db.markers = db.markers.filter(m => m.id !== req.params.id);
  writeJSON(FILES.markers, db);
  res.json({ deleted: before - db.markers.length });
});

// Orders basic scaffold
app.post('/api/orders', (req, res)=> {
  const db = readJSON(FILES.orders, { orders: [] });
  const { items = [], note } = req.body;
  const order = { id: uuidv4(), items, note: note || '', createdAt: new Date().toISOString(), status: 'new' };
  db.orders.push(order);
  writeJSON(FILES.orders, db);
  io.emit('orders:new', order);
  res.json({ saved: true, order });
});

app.get('/api/orders', (req, res)=> {
  const db = readJSON(FILES.orders, { orders: [] });
  res.json(db.orders);
});

// Fallback 404
app.use((req,res,next)=> next(createError(404)));
app.use((err, req, res, next)=> {
  res.status(err.status || 500).json({error: err.message || 'Server error'});
});

io.on('connection', (socket)=>{
  socket.emit('hello', {msg:'connected'});
});

server.listen(PORT, ()=> {
  console.log(`Cafe app listening on http://localhost:${PORT}`);
});
